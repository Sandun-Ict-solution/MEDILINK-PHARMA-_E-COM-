import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import mongoose, { Schema } from 'mongoose';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';
import { OAuth2Client } from 'google-auth-library';
import { z } from 'zod';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import multer from 'multer';

const env = process.env;
for (const key of ['MONGODB_URI','JWT_SECRET','FRONTEND_ORIGIN']) {
  if (!env[key]) throw new Error(`Missing ${key}; check .env`);
}
if (env.JWT_SECRET.length < 48) throw new Error('JWT_SECRET must be at least 48 characters');
const origin = env.FRONTEND_ORIGIN.replace(/\/$/, '');
const isProd = env.NODE_ENV === 'production';
const currency = env.STORE_CURRENCY || 'LKR';
const payhereReady = Boolean(env.PAYHERE_MERCHANT_ID && env.PAYHERE_MERCHANT_SECRET && env.PAYHERE_NOTIFY_URL);
const md5upper = value => crypto.createHash('md5').update(String(value)).digest('hex').toUpperCase();
const client = new OAuth2Client(env.GOOGLE_CLIENT_ID);
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin, credentials: true }));
app.use(express.json({limit:'100kb'}));
app.use(express.urlencoded({extended:false,limit:'20kb'}));
app.use(cookieParser());
// Local disk storage: mount a persistent volume at UPLOAD_DIR in production.
const uploadDir = path.resolve(env.UPLOAD_DIR || path.join(path.dirname(fileURLToPath(import.meta.url)), '../uploads'));
fs.mkdirSync(uploadDir, { recursive: true });
app.use('/uploads/private-prescriptions',(req,res)=>res.status(403).send('Forbidden'));
app.use('/uploads', express.static(uploadDir, { dotfiles: 'deny', index: false, maxAge: '1d', setHeaders(res) { res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Content-Security-Policy', "default-src 'none'; sandbox"); } }));
const imageSignatures = [
  {mime:'image/jpeg',ext:'.jpg',check:b=>b.length>3&&b[0]===255&&b[1]===216&&b[2]===255},
  {mime:'image/png',ext:'.png',check:b=>b.length>8&&b.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex'))},
  {mime:'image/webp',ext:'.webp',check:b=>b.length>12&&b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP'},
  {mime:'video/mp4',ext:'.mp4',check:b=>b.length>12&&b.toString('ascii',4,8)==='ftyp'},
];
const uploadCampaignMedia = multer({ storage: multer.memoryStorage(), limits: { fileSize: 80*1024*1024, files:1, fields:0 }, fileFilter(req,file,cb) { if (!imageSignatures.some(x=>x.mime===file.mimetype)) return cb(Object.assign(new Error('Unsupported media type'),{status:415})); cb(null,true); } });

// Limit credential attacks, not safe session/config reads or route navigation.
// Avoid 429 during ordinary /auth/me checks by leaving GET routes outside this limiter.
const credentialLimiter=rateLimit({windowMs:15*60*1000,limit:40,standardHeaders:'draft-7',legacyHeaders:false,
 message:{error:'Too many sign-in attempts. Please wait and retry.',code:'AUTH_RATE_LIMIT'},
 skipSuccessfulRequests:true});
app.use(['/api/auth/login','/api/auth/register','/api/auth/google','/api/auth/forgot-password','/api/admin/auth/login'],credentialLimiter);
const opts={timestamps:true};
const User=mongoose.model('User',new Schema({name:{type:String,required:true},email:{type:String,required:true,unique:true,lowercase:true,trim:true},passwordHash:{type:String,select:false},googleSub:{type:String,sparse:true,unique:true},emailVerified:{type:Boolean,default:false},role:{type:String,enum:['customer','admin','pharmacist','delivery'],default:'customer'},phone:{type:String,default:''},smsOptIn:{type:Boolean,default:false},favourites:[String]},opts));
const AdminInvite=mongoose.model('AdminInvite',new Schema({email:{type:String,required:true,lowercase:true,trim:true,index:true},tokenHash:{type:String,required:true,unique:true},expiresAt:{type:Date,required:true},acceptedAt:Date,invitedBy:{type:Schema.Types.ObjectId,ref:'User',required:true}},opts));
const Product=mongoose.model('Product',new Schema({sku:{type:String,required:true,unique:true},name:{type:String,required:true},priceMinor:{type:Number,required:true,min:0},currency:{type:String,required:true},stock:{type:Number,default:0,min:0},active:{type:Boolean,default:true},prescriptionRequired:{type:Boolean,default:false}},opts));
const Order=mongoose.model('Order',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},items:[{sku:String,name:String,quantity:Number,priceMinor:Number}],totalMinor:{type:Number,required:true},currency:String,status:{type:String,enum:['pending','cod_pending','paid','shipped','delivered','cancelled','refunded'],default:'pending'},paypalOrderId:{type:String,unique:true,sparse:true},paypalCaptureId:{type:String,unique:true,sparse:true},address:{type:String,default:''},payherePaymentId:{type:String,sparse:true},paymentMethod:{type:String,enum:['cod','payhere','paypal'],default:'cod'},statusHistory:[{status:String,at:Date}],paidAt:Date},opts));
const Campaign=mongoose.model('Campaign',new Schema({title:{type:String,required:true,maxlength:120},subtitle:{type:String,default:'',maxlength:300},buttonText:{type:String,default:'Shop now',maxlength:60},buttonUrl:{type:String,default:'/products',maxlength:500},mediaType:{type:String,enum:['image','video'],default:'image'},mediaUrl:{type:String,required:true,maxlength:1000},posterUrl:{type:String,default:'',maxlength:1000},animation:{type:String,enum:['fade','slide','zoom'],default:'fade'},active:{type:Boolean,default:false},startsAt:Date,endsAt:Date,sortOrder:{type:Number,default:0}},opts));
const SmsLog=mongoose.model('SmsLog',new Schema({user:{type:Schema.Types.ObjectId,ref:'User'},phone:String,type:String,message:String,provider:String,status:String,providerId:String,error:String},opts));
const Notice=mongoose.model('Notice',new Schema({user:{type:Schema.Types.ObjectId,ref:'User'},email:String,type:String,subject:String,status:{type:String,default:'pending'},error:String,sentAt:Date},opts));
const ReturnRequest=mongoose.model('ReturnRequest',new Schema({order:{type:Schema.Types.ObjectId,ref:'Order',required:true,index:true},user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},reason:{type:String,enum:['damaged','wrong_item','missing_item','quality_concern','other'],required:true},details:{type:String,required:true,maxlength:1500},status:{type:String,enum:['submitted','under_review','approved','rejected','resolved'],default:'submitted'},adminNote:{type:String,default:''},processedAt:Date},opts));
// Proposal modules: operational records, not clinical decision-making.
const Prescription=mongoose.model('Prescription',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},patientName:{type:String,required:true},contact:{type:String,required:true},notes:String,filename:String,storageName:String,mimeType:String,status:{type:String,enum:['pending','under_review','approved','rejected'],default:'pending'},reviewedBy:{type:Schema.Types.ObjectId,ref:'User'},reviewNote:String,reviewedAt:Date},opts));
const InventoryBatch=mongoose.model('InventoryBatch',new Schema({sku:{type:String,required:true,index:true},batchNumber:{type:String,required:true},quantity:{type:Number,required:true,min:0},expiresAt:{type:Date,required:true},supplier:String},opts));
InventoryBatch.schema.index({sku:1,batchNumber:1},{unique:true});
// GRN ledger: receipt numbers are unique; received quantities are additive, never overwritten.
const GoodsReceipt=mongoose.model('GoodsReceipt',new Schema({grnNumber:{type:String,required:true,unique:true,trim:true},supplier:{type:String,required:true},invoiceNumber:String,receivedAt:{type:Date,required:true},items:[{sku:{type:String,required:true},batchNumber:{type:String,required:true},quantity:{type:Number,required:true,min:1},unitCostMinor:{type:Number,required:true,min:0},expiresAt:{type:Date,required:true}}],receivedBy:{type:Schema.Types.ObjectId,ref:'User',required:true},totalCostMinor:{type:Number,required:true,min:0},currency:{type:String,default:'LKR'}},opts));
const Review=mongoose.model('Review',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true},sku:{type:String,required:true,index:true},rating:{type:Number,required:true,min:1,max:5},comment:{type:String,required:true},status:{type:String,enum:['pending','published','rejected'],default:'pending'}},opts));
const Refill=mongoose.model('Refill',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},medicine:{type:String,required:true},dueAt:{type:Date,required:true},consent:{type:Boolean,required:true},status:{type:String,enum:['active','paused','cancelled'],default:'active'},lastReminderAt:Date},opts));
const Delivery=mongoose.model('Delivery',new Schema({order:{type:Schema.Types.ObjectId,ref:'Order',required:true,unique:true},rider:{type:Schema.Types.ObjectId,ref:'User'},status:{type:String,enum:['assigned','picked_up','on_the_way','delivered'],default:'assigned'},eta:Date,locationNote:String,events:[{status:String,at:Date}]},opts));

// Persistent in-app notifications; only the recipient may view them.
const InAppNotification=mongoose.model('InAppNotification',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},order:{type:Schema.Types.ObjectId,ref:'Order'},title:{type:String,required:true,maxlength:140},message:{type:String,required:true,maxlength:700},readAt:Date},{timestamps:true}));
async function pushCustomerNotice(user,order,title,message){try{await InAppNotification.create({user,order,title,message});}catch(e){console.error('Notification persistence failed',e.message);}}
const AuditLog=mongoose.model('AuditLog',new Schema({actor:{type:Schema.Types.ObjectId,ref:'User'},action:String,target:String,at:{type:Date,default:Date.now}},opts));
const Verify=mongoose.model('Verify',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true},tokenHash:{type:String,unique:true},expiresAt:{type:Date,required:true,index:{expires:0}}},opts));
const PasswordReset=mongoose.model('PasswordReset',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},tokenHash:{type:String,required:true,unique:true},expiresAt:{type:Date,required:true,index:{expires:0}}},opts));
const publicUser=u=>({id:String(u._id),name:u.name,email:u.email,emailVerified:u.emailVerified,role:u.role==='admin' && !(String(process.env.ADMIN_ALLOWED_EMAILS||process.env.ADMIN_EMAIL||'').toLowerCase().split(',').map(s=>s.trim()).includes(String(u.email||'').toLowerCase()))?'customer':u.role,phone:u.phone,smsOptIn:u.smsOptIn,favourites:u.favourites});
const tokenFor=u=>jwt.sign({sub:String(u._id)},env.JWT_SECRET,{algorithm:'HS256',expiresIn:'2h',issuer:'medilink-api',audience:'medilink-web'});
function setCookie(res,u){res.cookie('medilink_session',tokenFor(u),{httpOnly:true,secure:isProd,sameSite:'lax',path:'/',maxAge:2*60*60*1000});}
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const validPhone = s => /^\+[1-9]\d{7,14}$/.test(s || '');
async function sms(user,type,message){
 if(!user?.smsOptIn || !validPhone(user.phone))return;
 const provider=env.SMS_PROVIDER||'console';
 const log=await SmsLog.create({user:user._id,phone:user.phone,type,message,provider,status:'pending'});
 if(provider==='disabled'){await SmsLog.updateOne({_id:log.id},{status:'disabled'});return;}
 if(provider==='console'){console.log(`[SMS SIMULATION to ${user.phone}] ${message}`);await SmsLog.updateOne({_id:log.id},{status:'simulated'});return;}
 if(provider!=='twilio' || !env.TWILIO_ACCOUNT_SID || !env.TWILIO_AUTH_TOKEN || !env.TWILIO_FROM){await SmsLog.updateOne({_id:log.id},{status:'not_configured'});return;}
 try{
  const payload=new URLSearchParams({To:user.phone,From:env.TWILIO_FROM,Body:message});
  const auth=Buffer.from(`${env.TWILIO_ACCOUNT_SID}:${env.TWILIO_AUTH_TOKEN}`).toString('base64');
  const response=await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(env.TWILIO_ACCOUNT_SID)}/Messages.json`,{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/x-www-form-urlencoded'},body:payload.toString(),signal:AbortSignal.timeout(10000)});
  const result=await response.json();
  if(!response.ok)throw new Error(result.message || `HTTP ${response.status}`);
  await SmsLog.updateOne({_id:log.id},{status:result.status||'accepted',providerId:result.sid});
 }catch(e){console.error('SMS delivery error',e.message);await SmsLog.updateOne({_id:log.id},{status:'failed',error:String(e.message).slice(0,200)});}
}
const transport=env.SMTP_HOST?nodemailer.createTransport({host:env.SMTP_HOST,port:Number(env.SMTP_PORT||587),secure:env.SMTP_SECURE==='true',auth:env.SMTP_USER?{user:env.SMTP_USER,pass:env.SMTP_PASS}:undefined}):null;
async function mail(user,type,subject,text,html){
 const rec=await Notice.create({user:user?._id,email:user?.email,type,subject,status:'pending'});
 if(!transport){await Notice.updateOne({_id:rec._id},{status:'not_configured'});return;}
 try{
  const info=await transport.sendMail({from:env.MAIL_FROM,to:user.email,subject,text,...(html?{html}:{})});
  await Notice.updateOne({_id:rec._id},{status:info.accepted?.includes(user.email)?'sent':'rejected',sentAt:new Date()});
 }catch(e){await Notice.updateOne({_id:rec._id},{status:'failed',error:String(e.message).slice(0,200)});console.error('Mail failed:',e.message);}
}
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const money=(minor,curr)=>`${curr||'LKR'} ${(Number(minor||0)/100).toLocaleString('en-LK',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const statusLabel={pending:'Order created',cod_pending:'Order received — Cash on delivery',paid:'Payment confirmed',shipped:'Dispatched for delivery',delivered:'Delivered',cancelled:'Cancelled',refunded:'Refunded'};
function orderEmail(order,user,heading){
 const id=String(order._id);const state=statusLabel[order.status]||order.status;
 const rows=order.items.map(i=>`<tr><td style="padding:11px;border-bottom:1px solid #e4eeec">${escapeHtml(i.name)}<br><small>${escapeHtml(i.sku||'')}</small></td><td style="padding:11px;text-align:center;border-bottom:1px solid #e4eeec">${Number(i.quantity)}</td><td style="padding:11px;text-align:right;border-bottom:1px solid #e4eeec">${escapeHtml(money(i.priceMinor*i.quantity,order.currency))}</td></tr>`).join('');
 const steps=['Order received','Payment / pharmacist review','Dispatched','Delivered'];
 const active=order.status==='delivered'?3:order.status==='shipped'?2:order.status==='paid'?1:0;
 const detail=order.items.map(i=>`- ${i.name} × ${i.quantity}: ${money(i.priceMinor*i.quantity,order.currency)}`).join('\n');
 const text=`MEDILINK — ${heading}\nOrder: ${id}\nStatus: ${state}\n\nItems:\n${detail}\n\nOrder total: ${money(order.totalMinor,order.currency)}\nPayment method: ${order.paymentMethod==='cod'?'Cash on delivery':order.paymentMethod==='payhere'?'PayHere card':'PayPal'}\nDelivery address: ${order.address||'Not provided'}\n\nTrack your order: ${origin}/orders\n\nPharmacist review and delivery milestones are confirmed only after the relevant order status is updated.`;
 const timeline=steps.map((step,i)=>`<td style="padding:7px 3px;font-size:12px;text-align:center;color:${i<=active?'#058661':'#8b9ba0'};font-weight:${i<=active?'700':'400'}">${i<=active?'&#10003; ':'&#9675; '}${escapeHtml(step)}</td>`).join('');
 const html=`<!doctype html><html><body style="margin:0;background:#f1f7f6;font:15px Arial,sans-serif;color:#163e4b"><div style="max-width:650px;margin:24px auto;background:white;border-radius:16px;overflow:hidden;border:1px solid #d6e7e7"><div style="padding:25px 30px;background:#078b67;color:#fff"><h1 style="margin:0;font-size:25px">&#10010; MEDILINK</h1><p style="margin:9px 0 0">${escapeHtml(heading)}</p></div><div style="padding:26px 30px"><p>Hello ${escapeHtml(user.name)},</p><p>Here are the latest details for your order.</p><p><strong>Order ID:</strong> ${escapeHtml(id)}<br><strong>Status:</strong> ${escapeHtml(state)}</p><table style="width:100%;border-collapse:collapse"><thead><tr style="background:#eef8f4"><th style="padding:11px;text-align:left">Item</th><th>Qty</th><th style="text-align:right;padding:11px">Line total</th></tr></thead><tbody>${rows}</tbody></table><p style="text-align:right;font-size:19px"><strong>Total: ${escapeHtml(money(order.totalMinor,order.currency))}</strong></p><p><strong>Payment:</strong> ${escapeHtml(order.paymentMethod==='cod'?'Cash on delivery':order.paymentMethod==='payhere'?'PayHere card':'PayPal')}<br><strong>Delivery:</strong> ${escapeHtml(order.address||'Not provided')}</p><h3>Order tracking</h3><table style="width:100%;border-collapse:collapse"><tr>${timeline}</tr></table><p style="font-size:12px;color:#60747a">Only confirmed milestones are shown. Pharmacist review may be required before dispatch.</p><p><a href="${escapeHtml(origin)}/orders" style="display:inline-block;background:#078b67;color:#fff;padding:12px 22px;text-decoration:none;border-radius:7px">Track your order</a></p></div><div style="padding:16px 30px;background:#eef8f4;font-size:12px">MEDILINK Pharmacy · This is a transactional order notification.</div></div></body></html>`;
 return {text,html};
}
async function notifyOrder(user,order,type){
 const subject=`MEDILINK Order #${String(order._id).slice(-8).toUpperCase()} — ${statusLabel[order.status]||order.status}`;
 const content=orderEmail(order,user,statusLabel[order.status]||'Order update');
 await mail(user,type,subject,content.text,content.html);
 await sms(user,type,`MEDILINK order ${String(order._id).slice(-8).toUpperCase()}: ${statusLabel[order.status]||order.status}. Track at ${origin}/orders`);
}
async function issueVerification(u){const raw=crypto.randomBytes(32).toString('hex');await Verify.deleteMany({user:u._id});await Verify.create({user:u._id,tokenHash:sha(raw),expiresAt:new Date(Date.now()+24*3600e3)});const link=`${env.API_PUBLIC_URL||'http://localhost:4000'}/api/auth/verify-email?token=${raw}`;await mail(u,'email_verification','Verify your MEDILINK email',`Verify your email: ${link}\nLink expires in 24 hours.`);}
async function auth(req,res,next){try{const t=req.cookies.medilink_session || (req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):null);if(!t)return res.status(401).json({error:'Authentication required'});const payload=jwt.verify(t,env.JWT_SECRET,{algorithms:['HS256'],issuer:'medilink-api',audience:'medilink-web'});const user=await User.findById(payload.sub);if(!user)return res.status(401).json({error:'Invalid session'});req.user=user;next();}catch{return res.status(401).json({error:'Invalid or expired session'});}}
const verified=(req,res,next)=>req.user.emailVerified?next():res.status(403).json({error:'Verify email first'});
// Defence in depth: admin role AND explicitly approved email are required.
// ADMIN_ALLOWED_EMAILS is comma-separated. Falls back to the bootstrap ADMIN_EMAIL.
const approvedAdminEmails = () => new Set(String(env.ADMIN_ALLOWED_EMAILS || env.ADMIN_EMAIL || '').split(',').map(x=>x.trim().toLowerCase()).filter(Boolean));
const allowedAdmin = user => Boolean(user && user.role==='admin' && user.emailVerified && approvedAdminEmails().has(String(user.email||'').toLowerCase()));
const admin=(req,res,next)=>allowedAdmin(req.user)?next():res.status(403).json({error:'Administrator email not authorized'});
const staff=(req,res,next)=>['admin','pharmacist'].includes(req.user.role)?next():res.status(403).json({error:'Pharmacist or admin only'});
const deliveryStaff=(req,res,next)=>['admin','delivery'].includes(req.user.role)?next():res.status(403).json({error:'Delivery staff only'});
const wrap=fn=>(req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);
const register=z.object({name:z.string().trim().min(2).max(100),email:z.string().email().max(254).transform(s=>s.toLowerCase()),password:z.string().min(10).max(128),phone:z.string().regex(/^\+[1-9]\d{7,14}$/).optional(),smsOptIn:z.boolean().optional()});
app.get('/api/health',(req,res)=>res.json({status:'ok',database:mongoose.connection.readyState===1?'connected':'offline'}));
app.post('/api/auth/register',wrap(async(req,res)=>{const v=register.parse(req.body);if(await User.exists({email:v.email}))return res.status(409).json({error:'Email already registered'});const passwordHash=await bcrypt.hash(v.password,12);const u=await User.create({name:v.name,email:v.email,phone:v.phone||'',smsOptIn:!!v.smsOptIn,passwordHash});if(transport) {try {await issueVerification(u);}catch(e){console.error('Verification email setup failed:',e.message);}}await sms(u,'registration','Welcome to MEDILINK. Your account has been created.');res.status(201).json({message:transport?'Registered successfully. You can sign in now; verify your email to place orders.':'Registered successfully. You can sign in now. Email verification is unavailable until SMTP is configured.',emailVerificationRequired:true});}));
app.get('/api/auth/verify-email',wrap(async(req,res)=>{const raw=String(req.query.token||'');if(!/^[a-f0-9]{64}$/.test(raw))return res.status(400).send('Invalid token');const record=await Verify.findOneAndDelete({tokenHash:sha(raw),expiresAt:{$gt:new Date()}});if(!record)return res.status(400).send('Invalid or expired verification link');await User.updateOne({_id:record.user},{emailVerified:true});if(env.ADMIN_EMAIL){await User.updateOne({_id:record.user,email:env.ADMIN_EMAIL.trim().toLowerCase(),role:'customer',emailVerified:true},{$set:{role:'admin'}});}res.redirect(303,`${origin}/?emailVerified=1`);}));
app.post('/api/auth/resend-verification',wrap(async(req,res)=>{const email=z.string().email().parse(req.body.email).toLowerCase();const u=await User.findOne({email});if(u&&!u.emailVerified)await issueVerification(u);res.json({message:'If eligible, a verification email has been sent.'});}));
const lastLoginAlert=new Map();
function loginAlert(user){
 if(!transport || !user?.emailVerified) return;
 const key=String(user._id),now=Date.now();
 if(now-(lastLoginAlert.get(key)||0)<60*60*1000)return;
 lastLoginAlert.set(key,now);
 // Send asynchronously; a mail transport outage must not fail authentication.
 void mail(user,'login_alert','MEDILINK sign-in notification',
   `A sign-in to your MEDILINK account was completed at ${new Date(now).toISOString()}. If this wasn't you, change your password and contact medilinklankapharma@gmail.com.`)
 .catch(e=>console.error('Login notice failed:',e.message));
 if(lastLoginAlert.size>10000)lastLoginAlert.clear();
}
app.post('/api/auth/login',wrap(async(req,res)=>{const v=z.object({email:z.string().email(),password:z.string()}).parse(req.body);const u=await User.findOne({email:v.email.toLowerCase()}).select('+passwordHash');if(!u?.passwordHash || !await bcrypt.compare(v.password,u.passwordHash))return res.status(401).json({error:'Invalid credentials'});setCookie(res,u);loginAlert(u);res.json({user:publicUser(u)});}));
// Separate admin sign-in. Regular customer login never grants admin privileges.
app.post('/api/admin/auth/login',wrap(async(req,res)=>{
 const v=z.object({email:z.string().email(),password:z.string().min(1)}).parse(req.body);
 const u=await User.findOne({email:v.email.toLowerCase(),role:'admin',emailVerified:true}).select('+passwordHash');
 if(!u?.passwordHash||!allowedAdmin(u)||!await bcrypt.compare(v.password,u.passwordHash))return res.status(401).json({error:'Invalid admin credentials or access not approved'});
 setCookie(res,u);loginAlert(u);await AuditLog.create({actor:u._id,action:'admin_login',target:String(u._id)});res.json({user:publicUser(u)});
}));
app.post('/api/admin/invitations',auth,verified,admin,wrap(async(req,res)=>{
 const {email}=z.object({email:z.string().email()}).parse(req.body);const target=email.toLowerCase();
 if(!approvedAdminEmails().has(target))return res.status(403).json({error:'Email must first be included in ADMIN_ALLOWED_EMAILS by the system owner'});
 const u=await User.findOne({email:target,emailVerified:true});
 if(!u)return res.status(409).json({error:'Recipient must register and verify their email first'});
 if(u.role==='admin')return res.status(409).json({error:'Already an administrator'});
 const raw=crypto.randomBytes(32).toString('hex');
 await AdminInvite.deleteMany({email:target,acceptedAt:{$exists:false}});
 const invite=await AdminInvite.create({email:target,tokenHash:sha(raw),expiresAt:new Date(Date.now()+24*3600e3),invitedBy:req.user._id});
 const link=`${origin}/admin/accept?token=${raw}`;
 const outcome=await mail(u,'admin_invite','MEDILINK administrator invitation',`A MEDILINK administrator invited you to join the operations portal. This link expires in 24 hours: ${link}`);
 await AuditLog.create({actor:req.user._id,action:'admin_invite',target:target});
 res.status(201).json({message:'Invitation created. Check email delivery logs.',email:target,inviteId:String(invite._id)});
}));
app.post('/api/admin/invitations/accept',auth,verified,wrap(async(req,res)=>{
 const {token}=z.object({token:z.string().regex(/^[a-f0-9]{64}$/)}).parse(req.body);
 const invite=await AdminInvite.findOne({tokenHash:sha(token),expiresAt:{$gt:new Date()},acceptedAt:{$exists:false},email:req.user.email});
 if(!invite)return res.status(400).json({error:'Invitation expired, already used, or intended for another verified email'});
 if(!approvedAdminEmails().has(req.user.email.toLowerCase()))return res.status(403).json({error:'Email not on approved administrator list'});
 const updated=await AdminInvite.updateOne({_id:invite._id,acceptedAt:{$exists:false}},{$set:{acceptedAt:new Date()}});
 if(!updated.modifiedCount)return res.status(409).json({error:'Invitation already accepted'});
 req.user.role='admin';await req.user.save();await AuditLog.create({actor:req.user._id,action:'admin_invite_accepted',target:String(invite._id)});
 res.json({user:publicUser(req.user)});
}));
app.post('/api/auth/google',wrap(async(req,res)=>{if(!env.GOOGLE_CLIENT_ID)return res.status(503).json({error:'Google OAuth not configured'});const credential=z.object({credential:z.string().min(100)}).parse(req.body).credential;const ticket=await client.verifyIdToken({idToken:credential,audience:env.GOOGLE_CLIENT_ID});const p=ticket.getPayload();if(!p?.sub||!p.email||!p.email_verified)return res.status(401).json({error:'Google identity not verified'});let u=await User.findOne({email:p.email.toLowerCase()});if(u&&!u.googleSub && !p.email.toLowerCase().endsWith('@gmail.com'))return res.status(409).json({error:'Existing account: sign in with password first, then link Google in account settings.'});if(u?.googleSub&&u.googleSub!==p.sub)return res.status(403).json({error:'Google account mismatch'});if(!u)u=await User.create({email:p.email,name:p.name||p.email.split('@')[0],googleSub:p.sub,emailVerified:true});else {u.googleSub=p.sub;u.emailVerified=true;await u.save();}setCookie(res,u);loginAlert(u);res.json({user:publicUser(u)});}));
// Password recovery: tokens are hashed in DB, single-use, 20 minute expiry.
// Requests always return the same message to avoid account enumeration.
app.post('/api/auth/forgot-password',wrap(async(req,res)=>{
 const {email}=z.object({email:z.string().email().max(254)}).parse(req.body);
 const u=await User.findOne({email:email.trim().toLowerCase()});
 if(u&&transport){
  const raw=crypto.randomBytes(32).toString('hex');
  await PasswordReset.deleteMany({user:u._id});
  await PasswordReset.create({user:u._id,tokenHash:sha(raw),expiresAt:new Date(Date.now()+20*60*1000)});
  const url=`${origin}/reset-password?token=${raw}`;
  await mail(u,'password_reset','Reset your MEDILINK password',`You requested a password reset. Open this link within 20 minutes: ${url}\nIf this was not you, ignore this email.`);
 }
 res.json({message:'If this email is registered and mail delivery is configured, a reset link will be sent.'});
}));
app.post('/api/auth/reset-password',wrap(async(req,res)=>{
 const {token,password}=z.object({token:z.string().regex(/^[a-f0-9]{64}$/),password:z.string().min(10).max(128)}).parse(req.body);
 const entry=await PasswordReset.findOneAndDelete({tokenHash:sha(token),expiresAt:{$gt:new Date()}});
 if(!entry)return res.status(400).json({error:'Reset link is invalid or expired. Request a new link.'});
 const hash=await bcrypt.hash(password,12);
 await User.updateOne({_id:entry.user},{$set:{passwordHash:hash}});
 await PasswordReset.deleteMany({user:entry.user});
 await AuditLog.create({actor:entry.user,action:'password_reset_completed',target:String(entry.user)});
 res.json({message:'Password updated. Please sign in with your new password.'});
}));
app.get('/api/auth/google-config',(req,res)=>res.json({clientId:env.GOOGLE_CLIENT_ID||null}));
app.get('/api/auth/me',auth,(req,res)=>res.json({user:publicUser(req.user)}));
app.post('/api/auth/logout',(req,res)=>{res.clearCookie('medilink_session',{httpOnly:true,secure:isProd,sameSite:'lax',path:'/'});res.json({ok:true});});
app.patch('/api/account/profile',auth,wrap(async(req,res)=>{
 const v=z.object({name:z.string().trim().min(2).max(100).optional(),phone:z.string().regex(/^\+[1-9]\d{7,14}$/).or(z.literal('')).optional()}).strict().parse(req.body);
 if(!Object.keys(v).length)return res.status(400).json({error:'No profile changes provided'});
 Object.assign(req.user,v);await req.user.save();res.json({user:publicUser(req.user)});
}));
app.patch('/api/account/notifications',auth,wrap(async(req,res)=>{const v=z.object({phone:z.string().regex(/^\+[1-9]\d{7,14}$/).or(z.literal('')),smsOptIn:z.boolean()}).parse(req.body);req.user.phone=v.phone;req.user.smsOptIn=!!v.smsOptIn && !!v.phone;await req.user.save();res.json({user:publicUser(req.user)});}));
// Marketing campaigns: public feed and admin-only authoring. Media is referenced by URL (no untrusted uploads).
const validCampaignMedia=(url)=>(url.startsWith('/assets/')||url.startsWith('/uploads/'))||/^https:\/\/[^\s]+$/i.test(url);
const campaignSchema=z.object({title:z.string().trim().min(2).max(120),subtitle:z.string().max(300).default(''),buttonText:z.string().max(60).default('Shop now'),buttonUrl:z.string().max(500).refine(x=>x.startsWith('/')&&!x.startsWith('//'),'Internal path required').default('/products'),mediaType:z.enum(['image','video']).default('image'),mediaUrl:z.string().max(1000).refine(validCampaignMedia,'Use /uploads/, /assets/ or HTTPS media URL'),posterUrl:z.string().max(1000).refine(x=>!x||validCampaignMedia(x),'Invalid poster URL').default(''),animation:z.enum(['fade','slide','zoom']).default('fade'),active:z.boolean().default(false),startsAt:z.coerce.date().nullable().optional(),endsAt:z.coerce.date().nullable().optional(),sortOrder:z.number().int().min(-1000).max(1000).default(0)}).refine(x=>!x.startsAt||!x.endsAt||x.endsAt>x.startsAt,'End date must be after start date');
app.get('/api/campaigns',wrap(async(req,res)=>{const now=new Date();const campaigns=await Campaign.find({active:true,$and:[{$or:[{startsAt:{$exists:false}},{startsAt:null},{startsAt:{$lte:now}}]},{$or:[{endsAt:{$exists:false}},{endsAt:null},{endsAt:{$gt:now}}]}]}).select('title subtitle buttonText buttonUrl mediaType mediaUrl posterUrl animation sortOrder').sort({sortOrder:1,createdAt:-1}).limit(30).lean();res.json({campaigns});}));
// Admin-only multipart upload. Files are identified from their bytes, not their supplied filename.
app.post('/api/admin/campaigns/upload',auth,verified,admin,uploadCampaignMedia.single('file'),wrap(async(req,res)=>{
 if(!req.file)return res.status(400).json({error:'Choose a JPEG, PNG, WebP or MP4 file'});
 const signature=imageSignatures.find(x=>x.check(req.file.buffer));
 if(!signature || signature.mime!==req.file.mimetype) return res.status(415).json({error:'File content does not match allowed type'});
 const isVideo=signature.mime==='video/mp4';
 if(!isVideo && req.file.size>10*1024*1024)return res.status(413).json({error:'Image maximum is 10 MB'});
 const filename=`${crypto.randomUUID()}${signature.ext}`;
 // Exclusive creation prevents an overwrite even in the unlikely event of a filename collision.
 await fs.promises.writeFile(path.join(uploadDir,filename),req.file.buffer,{flag:'wx',mode:0o600});
 return res.status(201).json({mediaUrl:`/uploads/${filename}`,mediaType:isVideo?'video':'image',bytes:req.file.size});
}));
app.get('/api/admin/campaigns',auth,verified,admin,wrap(async(req,res)=>res.json({campaigns:await Campaign.find().sort({sortOrder:1,createdAt:-1}).limit(200).lean()})));
app.post('/api/admin/campaigns',auth,verified,admin,wrap(async(req,res)=>{const data=campaignSchema.parse(req.body);const campaign=await Campaign.create(data);res.status(201).json({campaign});}));
app.patch('/api/admin/campaigns/:id',auth,verified,admin,wrap(async(req,res)=>{const changes=campaignSchema.partial().parse(req.body);if(Object.keys(changes).length===0)return res.status(400).json({error:'No changes'});const campaign=await Campaign.findByIdAndUpdate(req.params.id,{$set:changes},{new:true,runValidators:true});if(!campaign)return res.status(404).json({error:'Campaign not found'});if(campaign.startsAt&&campaign.endsAt&&campaign.endsAt<=campaign.startsAt)return res.status(400).json({error:'Invalid campaign date range'});res.json({campaign});}));
app.delete('/api/admin/campaigns/:id',auth,verified,admin,wrap(async(req,res)=>{const deleted=await Campaign.findByIdAndDelete(req.params.id);if(!deleted)return res.status(404).json({error:'Campaign not found'});res.json({ok:true});}));
app.get('/api/products',wrap(async(req,res)=>res.json({products:await Product.find({active:true}).select('-__v').lean()})));
app.post('/api/admin/products',auth,verified,admin,wrap(async(req,res)=>{const v=z.object({sku:z.string().min(1),name:z.string().min(1),priceMinor:z.number().int().nonnegative(),currency:z.string().length(3),stock:z.number().int().nonnegative(),prescriptionRequired:z.boolean().optional()}).parse(req.body);const p=await Product.findOneAndUpdate({sku:v.sku},{$set:v},{new:true,upsert:true,runValidators:true});res.json({product:p});}));
app.get('/api/admin/products',auth,verified,admin,wrap(async(req,res)=>res.json({products:await Product.find().sort({name:1}).limit(500).lean()})));
app.patch('/api/admin/products/:sku',auth,verified,admin,wrap(async(req,res)=>{
 const v=z.object({name:z.string().trim().min(1).max(160).optional(),priceMinor:z.number().int().nonnegative().optional(),stock:z.number().int().nonnegative().optional(),active:z.boolean().optional()}).strict().parse(req.body);
 if(!Object.keys(v).length)return res.status(400).json({error:'No changes'});
 const product=await Product.findOneAndUpdate({sku:req.params.sku},{$set:v},{new:true,runValidators:true});if(!product)return res.status(404).json({error:'Product not found'});
 await AuditLog.create({actor:req.user._id,action:'product_updated',target:product.sku});res.json({product});
}));
app.delete('/api/admin/products/:sku',auth,verified,admin,wrap(async(req,res)=>{
 const product=await Product.findOneAndUpdate({sku:req.params.sku},{$set:{active:false}},{new:true});if(!product)return res.status(404).json({error:'Product not found'});
 await AuditLog.create({actor:req.user._id,action:'product_deactivated',target:product.sku});res.json({product,note:'Deactivated; order history preserved'});
}));
app.get('/api/favourites',auth,(req,res)=>res.json({favourites:req.user.favourites}));
app.put('/api/favourites',auth,wrap(async(req,res)=>{const items=z.array(z.string().max(120)).max(200).parse(req.body.favourites);req.user.favourites=[...new Set(items)];await req.user.save();res.json({favourites:req.user.favourites});}));
const paypalBase=()=>env.PAYPAL_ENV==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com';
async function paypalToken(){if(!env.PAYPAL_CLIENT_ID||!env.PAYPAL_CLIENT_SECRET)throw Object.assign(new Error('PayPal not configured'),{status:503});const b=Buffer.from(`${env.PAYPAL_CLIENT_ID}:${env.PAYPAL_CLIENT_SECRET}`).toString('base64');const r=await fetch(`${paypalBase()}/v1/oauth2/token`,{method:'POST',headers:{Authorization:`Basic ${b}`,'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});if(!r.ok)throw Object.assign(new Error('PayPal auth failed'),{status:502});return (await r.json()).access_token;}
async function paypal(path,method,body,idempotency){const t=await paypalToken();const r=await fetch(`${paypalBase()}${path}`,{method,headers:{Authorization:`Bearer ${t}`,'Content-Type':'application/json','PayPal-Request-Id':idempotency},...(body!==undefined?{body:JSON.stringify(body)}:{})});const data=await r.json().catch(()=>({}));if(!r.ok)throw Object.assign(new Error('PayPal request failed'),{status:502,detail:data});return data;}
app.post('/api/orders',auth,verified,wrap(async(req,res)=>{const v=z.object({items:z.array(z.object({sku:z.string(),quantity:z.number().int().min(1).max(20)})).min(1).max(50),address:z.string().max(500).optional()}).parse(req.body);const skus=v.items.map(i=>i.sku);if(new Set(skus).size!==skus.length)return res.status(400).json({error:'Duplicate SKUs'});const ps=await Product.find({sku:{$in:skus},active:true});const map=new Map(ps.map(p=>[p.sku,p]));const items=[];let total=0;for(const item of v.items){const p=map.get(item.sku);if(!p||p.stock<item.quantity||p.currency!==currency)return res.status(400).json({error:`Unavailable product or currency: ${item.sku}`});if(p.prescriptionRequired)return res.status(403).json({error:`Prescription validation required for ${item.sku}`});items.push({sku:p.sku,name:p.name,quantity:item.quantity,priceMinor:p.priceMinor});total+=p.priceMinor*item.quantity;}total += (total >= 150000 ? 0 : 35000) + 5000;if(!Number.isSafeInteger(total)||total<=0)return res.status(400).json({error:'Invalid total'});const o=await Order.create({user:req.user._id,items,totalMinor:total,currency,address:v.address||''});res.status(201).json({order:{id:String(o.id),status:o.status,totalMinor:total,currency}});}));
app.post('/api/orders/:id/cod',auth,verified,wrap(async(req,res)=>{const o=await Order.findOneAndUpdate({_id:req.params.id,user:req.user._id,status:'pending'},{$set:{status:'cod_pending',paymentMethod:'cod'},$push:{statusHistory:{status:'cod_pending',at:new Date()}}},{new:true});if(!o)return res.status(409).json({error:'Pending order not found'});await notifyOrder(req.user,o,'order_placed');res.json({order:o});}));
// Hosted PayHere checkout: do not collect or store PAN/CVV locally.
app.get('/api/payments/methods',(req,res)=>res.json({currency,methods:{cod:true,card:payhereReady,googlePay:false},reason:!payhereReady?'Configure PayHere merchant credentials and PUBLIC HTTPS notify URL first.':undefined}));
app.post('/api/payhere/create-checkout',auth,verified,wrap(async(req,res)=>{
 if(!payhereReady)return res.status(503).json({error:'Card payments are not configured. Add PayHere merchant credentials and a public HTTPS notify URL.'});
 const {orderId,firstName,lastName,email,phone,address,city}=z.object({orderId:z.string().regex(/^[a-f0-9]{24}$/i),firstName:z.string().trim().min(1).max(100),lastName:z.string().trim().min(1).max(100),email:z.string().email(),phone:z.string().min(9).max(20),address:z.string().trim().min(3).max(250),city:z.string().trim().min(2).max(100)}).parse(req.body);
 const order=await Order.findOne({_id:orderId,user:req.user._id});
 if(!order||order.status!=='pending')return res.status(409).json({error:'Pending order not found'});
 if(order.currency!=='LKR')return res.status(409).json({error:'PayHere checkout is configured for LKR orders only'});
 if(email.toLowerCase()!==req.user.email.toLowerCase())return res.status(400).json({error:'Checkout email must match your account'});
 const amount=(order.totalMinor/100).toFixed(2);const merchant=env.PAYHERE_MERCHANT_ID;const secretHash=md5upper(env.PAYHERE_MERCHANT_SECRET);
 const fields={merchant_id:merchant,return_url:`${origin}/orders?payment=return`,cancel_url:`${origin}/checkout?payment=cancel`,notify_url:env.PAYHERE_NOTIFY_URL,first_name:firstName,last_name:lastName,email:req.user.email,phone,address,city,country:'Sri Lanka',order_id:String(order._id),items:`MEDILINK order ${order._id}`,currency:order.currency,amount,hash:md5upper(`${merchant}${order._id}${amount}${order.currency}${secretHash}`)};
 await Order.updateOne({_id:order._id,status:'pending'},{$set:{paymentMethod:'payhere'}});
 return res.json({action:env.PAYHERE_ENV==='live'?'https://www.payhere.lk/pay/checkout':'https://sandbox.payhere.lk/pay/checkout',fields});
}));
// IMPORTANT: server-to-server notification ONLY; never trust browser redirects for payment success.
app.post('/api/payhere/notify',wrap(async(req,res)=>{
 const b=req.body||{};const merchant=String(b.merchant_id||'');const orderId=String(b.order_id||'');const amount=String(b.payhere_amount||'');const c=String(b.payhere_currency||'');const status=String(b.status_code||'');const sig=String(b.md5sig||'').toUpperCase();
 if(!payhereReady||merchant!==env.PAYHERE_MERCHANT_ID||!mongoose.isValidObjectId(orderId)||!/^-?\d+$/.test(status)||!/^\d+\.\d{2}$/.test(amount)||!(/^[0-9A-F]{32}$/.test(sig)))return res.status(400).send('Invalid notification');
 const expected=md5upper(`${merchant}${orderId}${amount}${c}${status}${md5upper(env.PAYHERE_MERCHANT_SECRET)}`);
 if(!crypto.timingSafeEqual(Buffer.from(expected,'hex'),Buffer.from(sig,'hex')))return res.status(403).send('Bad signature');
 const order=await Order.findById(orderId);
 if(!order||order.currency!==c||(order.totalMinor/100).toFixed(2)!==amount||order.paymentMethod!=='payhere')return res.status(409).send('Payment mismatch');
 if(status==='2'){
   const updated=await Order.findOneAndUpdate({_id:order._id,status:'pending',paymentMethod:'payhere'},{$set:{status:'paid',paidAt:new Date(),payherePaymentId:String(b.payment_id||'')},$push:{statusHistory:{status:'paid',at:new Date()}}},{new:true});
   if(updated){const user=await User.findById(updated.user);if(user){await notifyOrder(user,updated,'order_confirmed');}}
 }else if(['-1','-2','-3'].includes(status)){
   // Never mark any paid order as unpaid automatically; chargebacks require manual reconciliation.
   if(order.status==='pending')await Order.updateOne({_id:order._id,status:'pending'},{$set:{status:'cancelled'}});
 }
 return res.status(200).send('OK');
}));
// Return requests are review tickets, not automatic refunds or stock adjustments.
const returnInput=z.object({orderId:z.string().regex(/^[a-f0-9]{24}$/i),reason:z.enum(['damaged','wrong_item','missing_item','quality_concern','other']),details:z.string().trim().min(10).max(1500)});
app.post('/api/returns',auth,verified,wrap(async(req,res)=>{const data=returnInput.parse(req.body);const order=await Order.findOne({_id:data.orderId,user:req.user._id});if(!order)return res.status(404).json({error:'Order not found for this account'});const existing=await ReturnRequest.findOne({order:order._id,user:req.user._id,status:{$in:['submitted','under_review','approved']}});if(existing)return res.status(409).json({error:'An open request already exists for this order'});const request=await ReturnRequest.create({order:order._id,user:req.user._id,reason:data.reason,details:data.details});res.status(201).json({request:{id:String(request._id),status:request.status}})}));
app.get('/api/returns',auth,wrap(async(req,res)=>res.json({requests:await ReturnRequest.find({user:req.user._id}).select('order reason details status createdAt updatedAt').sort({createdAt:-1}).limit(100).lean()})));
app.get('/api/admin/returns',auth,verified,admin,wrap(async(req,res)=>res.json({requests:await ReturnRequest.find().sort({createdAt:-1}).limit(200).lean()})));
app.patch('/api/admin/returns/:id',auth,verified,admin,wrap(async(req,res)=>{const changes=z.object({status:z.enum(['under_review','approved','rejected','resolved']),adminNote:z.string().max(1000).optional()}).parse(req.body);const request=await ReturnRequest.findByIdAndUpdate(req.params.id,{$set:{...changes,processedAt:new Date()}},{new:true});if(!request)return res.status(404).json({error:'Request not found'});res.json({request})}));
app.get('/api/orders',auth,wrap(async(req,res)=>res.json({orders:await Order.find({user:req.user._id}).sort({createdAt:-1}).lean()})));
app.post('/api/paypal/create-order',auth,verified,wrap(async(req,res)=>{const id=z.string().regex(/^[a-f0-9]{24}$/i).parse(req.body.orderId);const order=await Order.findOne({_id:id,user:req.user._id});if(!order||order.status!=='pending')return res.status(404).json({error:'Pending order not found'});if(currency!=='USD')return res.status(409).json({error:'PayPal is disabled for LKR prices. Configure a legally supported conversion and USD pricing before enabling.'});if(order.paypalOrderId)return res.json({paypalOrderId:order.paypalOrderId});const p=await paypal('/v2/checkout/orders','POST',{intent:'CAPTURE',purchase_units:[{custom_id:String(order._id),amount:{currency_code:order.currency,value:(order.totalMinor/100).toFixed(2)}}],payment_source:{paypal:{experience_context:{return_url:`${origin}/?paypalReturn=1&orderId=${order.id}`,cancel_url:`${origin}/?paypalCancel=1&orderId=${order.id}`,user_action:'PAY_NOW'}}}},`create-${order.id}`);order.paypalOrderId=p.id;await order.save();res.json({paypalOrderId:p.id,approveUrl:p.links?.find(x=>x.rel==='approve'||x.rel==='payer-action')?.href});}));
app.post('/api/paypal/capture-order',auth,verified,wrap(async(req,res)=>{const id=z.string().regex(/^[a-f0-9]{24}$/i).parse(req.body.orderId);const o=await Order.findOne({_id:id,user:req.user._id});if(!o?.paypalOrderId)return res.status(404).json({error:'PayPal order not found'});if(o.status==='paid')return res.json({status:'paid',orderId:String(o.id)});
// Avoid duplicate capture calls; PayPal-Request-Id supplies provider-side idempotency.
const p=await paypal(`/v2/checkout/orders/${encodeURIComponent(o.paypalOrderId)}/capture`,'POST',{},`capture-${o.id}`);const pu=p.purchase_units?.[0];const capture=pu?.payments?.captures?.[0];if(p.id!==o.paypalOrderId||p.status!=='COMPLETED'||capture?.status!=='COMPLETED'||pu?.custom_id!==String(o.id)||capture.amount?.currency_code!==o.currency||capture.amount?.value!==(o.totalMinor/100).toFixed(2))return res.status(409).json({error:'Payment verification mismatch; manual review needed'});
const updated=await Order.findOneAndUpdate({_id:o.id,status:'pending'},{$set:{status:'paid',paypalCaptureId:capture.id,paidAt:new Date()},$push:{statusHistory:{status:'paid',at:new Date()}}},{new:true});if(updated){await notifyOrder(req.user,updated,'order_confirmed');}res.json({status:'paid',orderId:String(o.id)});}));
app.post('/api/admin/updates',auth,verified,admin,wrap(async(req,res)=>{const v=z.object({subject:z.string().min(3).max(140),message:z.string().min(3).max(3000)}).parse(req.body);const users=await User.find({emailVerified:true});for(const u of users){await mail(u,'news_update',v.subject,v.message);await sms(u,'news_update',`MEDILINK update: ${v.subject}. ${v.message.slice(0,110)}`);}res.json({recipients:users.length,message:'Delivery attempts recorded in MongoDB'});}));
app.get('/api/admin/sms-logs',auth,verified,admin,wrap(async(req,res)=>res.json({logs:await SmsLog.find().sort({createdAt:-1}).limit(100).lean()})));
app.patch('/api/admin/orders/:id/status',auth,verified,admin,wrap(async(req,res)=>{
 const next=z.enum(['shipped','delivered','cancelled']).parse(req.body.status);
 const allowed={pending:['cancelled'],cod_pending:['shipped','cancelled'],paid:['shipped'],shipped:['delivered']};
 const current=await Order.findById(req.params.id);
 if(!current)return res.status(404).json({error:'Order not found'});
 if(!allowed[current.status]?.includes(next))return res.status(409).json({error:`Cannot transition from ${current.status} to ${next}`});
 const o=await Order.findOneAndUpdate({_id:current._id,status:current.status},{$set:{status:next},$push:{statusHistory:{status:next,at:new Date()}}},{new:true});
 if(!o)return res.status(409).json({error:'Order status changed; refresh and retry'});
 const user=await User.findById(o.user);
 if(user){await pushCustomerNotice(user._id,o._id,'Order update',`Order status: ${o.status}`);await notifyOrder(user,o,'order_update');}
 res.json({order:o});
}));
app.get('/api/admin/orders',auth,verified,admin,wrap(async(req,res)=>res.json({orders:await Order.find().sort({createdAt:-1}).limit(200).lean()})));
app.get('/api/admin/notices',auth,verified,admin,wrap(async(req,res)=>res.json({notices:await Notice.find().sort({createdAt:-1}).limit(100).lean()})));

// Prescription uploads are PRIVATE: not served by express.static. Access through authenticated ownership/staff endpoints only.
const prescriptionDir=path.join(uploadDir,'private-prescriptions');fs.mkdirSync(prescriptionDir,{recursive:true});
const rxUpload=multer({storage:multer.memoryStorage(),limits:{fileSize:10*1024*1024,files:1},fileFilter(req,file,cb){if(!['application/pdf','image/png','image/jpeg'].includes(file.mimetype))return cb(Object.assign(new Error('Only PDF, PNG and JPEG allowed'),{status:415}));cb(null,true);}});
function rxFileType(b){if(b.subarray(0,4).toString()==='%PDF')return ['application/pdf','.pdf'];const m=imageSignatures.find(x=>x.mime!=='video/mp4'&&x.check(b));return m?[m.mime,m.ext]:null;}
app.post('/api/prescriptions',auth,verified,rxUpload.single('file'),wrap(async(req,res)=>{if(!req.file)return res.status(400).json({error:'File required'});const f=rxFileType(req.file.buffer);if(!f||f[0]!==req.file.mimetype)return res.status(415).json({error:'Invalid prescription content'});const v=z.object({patientName:z.string().trim().min(2).max(100),contact:z.string().trim().min(8).max(30),notes:z.string().max(1000).default(''),consent:z.enum(['true'])}).parse(req.body);const storageName=crypto.randomUUID()+f[1];await fs.promises.writeFile(path.join(prescriptionDir,storageName),req.file.buffer,{flag:'wx',mode:0o600});try{const record=await Prescription.create({user:req.user._id,...v,filename:req.file.originalname.slice(0,150),storageName,mimeType:f[0]});res.status(201).json({prescription:{id:String(record.id),status:record.status}});}catch(e){await fs.promises.unlink(path.join(prescriptionDir,storageName)).catch(()=>{});throw e;}}));
app.get('/api/prescriptions',auth,wrap(async(req,res)=>res.json({prescriptions:await Prescription.find({user:req.user._id}).select('-storageName').sort({createdAt:-1}).limit(100).lean()})));
app.get('/api/staff/prescriptions',auth,verified,staff,wrap(async(req,res)=>res.json({prescriptions:await Prescription.find().select('-storageName').sort({createdAt:-1}).limit(200).lean()})));
app.get('/api/prescriptions/:id/file',auth,wrap(async(req,res)=>{const p=await Prescription.findById(req.params.id);if(!p)return res.status(404).json({error:'Not found'});if(String(p.user)!==String(req.user.id)&&!['admin','pharmacist'].includes(req.user.role))return res.status(403).json({error:'Not authorized'});res.setHeader('Content-Type',p.mimeType);res.setHeader('Cache-Control','no-store');res.setHeader('Content-Disposition',`attachment; filename="prescription${path.extname(p.storageName)}"`);res.sendFile(path.join(prescriptionDir,p.storageName));}));
app.patch('/api/staff/prescriptions/:id',auth,verified,staff,wrap(async(req,res)=>{
 const v=z.object({status:z.enum(['under_review','approved','rejected']),reviewNote:z.string().trim().max(1000).default('')}).parse(req.body);
 if(v.status==='rejected'&&v.reviewNote.length<10)return res.status(400).json({error:'A clear rejection reason of at least 10 characters is required.'});
 if(v.status==='approved'&&v.reviewNote.length<5)return res.status(400).json({error:'Enter a pharmacist review note before approval.'});
 // Only a verified pharmacist or authorized administrator should perform prescription decisions.
 if(req.user.role==='pharmacist'&&!await PharmacistCredential.exists({user:req.user._id,status:'verified'}))return res.status(403).json({error:'Pharmacist credential verification required'});
 const prior=await Prescription.findById(req.params.id);
 if(!prior)return res.status(404).json({error:'Prescription not found'});
 if(['approved','rejected'].includes(prior.status))return res.status(409).json({error:'Prescription decision already finalized'});
 const p=await Prescription.findOneAndUpdate({_id:prior._id,status:{$in:['pending','under_review']}},{$set:{status:v.status,reviewNote:v.reviewNote,reviewedBy:req.user._id,reviewedAt:new Date()}},{new:true});
 if(!p)return res.status(409).json({error:'Another reviewer completed this prescription'});
 await AuditLog.create({actor:req.user._id,action:'prescription_'+v.status,target:String(p.id)});
 const customer=await User.findById(p.user);
 if(customer&&v.status!=='under_review'){
  const label=v.status==='approved'?'approved for processing':'rejected';
  const subject=`MEDILINK prescription ${v.status} · ${String(p._id).slice(-8)}`;
  const body=`Your prescription ${p._id} was ${label} after manual review.\nReview note: ${v.reviewNote}\nVisit ${origin}/prescription to view your status.\nApproval is not a prescription or permission to dispense without required professional checks.`;
  await pushCustomerNotice(customer._id,null,subject,body);
  await mail(customer,'prescription_'+v.status,subject,body);
 }
 res.json({prescription:{id:p.id,status:p.status,reviewNote:p.reviewNote},notification:'An in-app notification was saved; email delivery depends on SMTP and is logged separately.'});
}));
// Batch stock alerts use validated manual stock entry; automated dispensing allocation is not implemented.
const grnItemSchema=z.object({sku:z.string().trim().min(1).max(120),batchNumber:z.string().trim().min(1).max(120),quantity:z.number().int().min(1).max(100000),unitCostMinor:z.number().int().nonnegative(),expiresAt:z.coerce.date()});
app.get('/api/admin/grn',auth,verified,admin,wrap(async(req,res)=>res.json({receipts:await GoodsReceipt.find().sort({receivedAt:-1}).limit(150).lean()})));
app.post('/api/admin/grn',auth,verified,admin,wrap(async(req,res)=>{
 const v=z.object({grnNumber:z.string().trim().min(2).max(80),supplier:z.string().trim().min(2).max(120),invoiceNumber:z.string().trim().max(100).default(''),receivedAt:z.coerce.date(),items:z.array(grnItemSchema).min(1).max(50)}).parse(req.body);
 if(v.receivedAt>new Date(Date.now()+86400000))return res.status(400).json({error:'Receipt date cannot be in the future'});
 for(const i of v.items){if(i.expiresAt<=v.receivedAt)return res.status(400).json({error:`Expiry must be later than receipt date: ${i.sku}`});}
 if(new Set(v.items.map(i=>i.sku+'::'+i.batchNumber)).size!==v.items.length)return res.status(400).json({error:'Duplicate SKU and batch in one GRN'});
 const products=await Product.find({sku:{$in:v.items.map(i=>i.sku)}}).select('sku').lean();
 if(new Set(products.map(x=>x.sku)).size!==new Set(v.items.map(i=>i.sku)).size)return res.status(400).json({error:'One or more SKUs are not registered products'});
 const totalCostMinor=v.items.reduce((sum,i)=>sum+i.quantity*i.unitCostMinor,0);
 if(!Number.isSafeInteger(totalCostMinor))return res.status(400).json({error:'GRN total exceeds safe range'});
 // Multi-document stock mutations MUST use an Atlas replica-set transaction.
 const session=await mongoose.startSession();let receipt;
 try{await session.withTransaction(async()=>{
  const created=await GoodsReceipt.create([{...v,totalCostMinor,receivedBy:req.user._id,currency}],{session});receipt=created[0];
  for(const item of v.items){
   const batch=await InventoryBatch.findOne({sku:item.sku,batchNumber:item.batchNumber}).session(session);
   if(batch){if(new Date(batch.expiresAt).getTime()!==item.expiresAt.getTime())throw Object.assign(new Error('Batch expiry mismatch for '+item.sku),{status:409});await InventoryBatch.updateOne({_id:batch._id},{$inc:{quantity:item.quantity}},{session});}
   else await InventoryBatch.create([{sku:item.sku,batchNumber:item.batchNumber,quantity:item.quantity,expiresAt:item.expiresAt,supplier:v.supplier}],{session});
   await Product.updateOne({sku:item.sku},{$inc:{stock:item.quantity}},{session});
  }
  await AuditLog.create([{actor:req.user._id,action:'goods_receipt_created',target:v.grnNumber}],{session});
 });}
 catch(e){if(e?.code===11000)return res.status(409).json({error:'GRN number already exists'});throw e;}finally{await session.endSession();}
 res.status(201).json({receipt});
}));
app.get('/api/admin/sales-analytics',auth,verified,admin,wrap(async(req,res)=>{
 const days=Math.min(365,Math.max(1,Number.parseInt(String(req.query.days||30),10)||30));const from=new Date(Date.now()-days*86400000);
 const states=['paid','shipped','delivered','cod_pending'];
 const rows=await Order.aggregate([{$match:{createdAt:{$gte:from},status:{$in:states}}},{$group:{_id:{day:{$dateToString:{format:'%Y-%m-%d',date:'$createdAt'}},currency:'$currency',payment:'$paymentMethod',status:'$status'},orders:{$sum:1},totalMinor:{$sum:'$totalMinor'}}},{$sort:{'_id.day':1}}]);
 const products=await Order.aggregate([{$match:{createdAt:{$gte:from},status:{$in:states}}},{$unwind:'$items'},{$group:{_id:{sku:'$items.sku',name:'$items.name'},quantity:{$sum:'$items.quantity'},salesMinor:{$sum:{$multiply:['$items.quantity','$items.priceMinor']}}}},{$sort:{quantity:-1}},{$limit:15}]);
 const receipts=await GoodsReceipt.aggregate([{$match:{receivedAt:{$gte:from}}},{$group:{_id:'$currency',costMinor:{$sum:'$totalCostMinor'},count:{$sum:1}}}]);
 res.json({days,rows,products,receipts,disclaimer:'COD is ordered value, not cash collected. Sales exclude cancellations/refunds; product subtotals omit delivery/fees. GRN costs are not cost of goods sold; do not treat difference as profit.'});
}));
app.get('/api/staff/inventory',auth,verified,staff,wrap(async(req,res)=>{const batches=await InventoryBatch.find().sort({expiresAt:1}).limit(500).lean();const soon=new Date(Date.now()+90*86400000);res.json({batches:batches.map(b=>({...b,alert:b.quantity<=5?'low_stock':b.expiresAt<new Date()?'expired':b.expiresAt<soon?'expiring_soon':null}))});}));
app.post('/api/staff/inventory',auth,verified,staff,wrap(async(req,res)=>{const v=z.object({sku:z.string().min(1).max(120),batchNumber:z.string().min(1).max(120),quantity:z.number().int().nonnegative(),expiresAt:z.coerce.date(),supplier:z.string().max(120).optional()}).parse(req.body);if(!await Product.exists({sku:v.sku}))return res.status(404).json({error:'Unknown product SKU'});const b=await InventoryBatch.findOneAndUpdate({sku:v.sku,batchNumber:v.batchNumber},{$set:v},{new:true,upsert:true,runValidators:true});await AuditLog.create({actor:req.user._id,action:'inventory_update',target:`${v.sku}:${v.batchNumber}`});res.json({batch:b});}));
// Reviews remain private pending moderation; ratings cannot be self-published.
app.post('/api/reviews',auth,verified,wrap(async(req,res)=>{const v=z.object({sku:z.string().min(1),rating:z.number().int().min(1).max(5),comment:z.string().trim().min(5).max(1000)}).parse(req.body);if(!await Product.exists({sku:v.sku}))return res.status(404).json({error:'Unknown product'});const review=await Review.create({user:req.user._id,...v});res.status(201).json({review:{id:review.id,status:'pending'}});}));
app.get('/api/reviews',wrap(async(req,res)=>{const sku=z.string().min(1).parse(req.query.sku);res.json({reviews:await Review.find({sku,status:'published'}).select('sku rating comment createdAt').sort({createdAt:-1}).limit(100).lean()});}));
app.get('/api/admin/reviews',auth,verified,admin,wrap(async(req,res)=>res.json({reviews:await Review.find().sort({createdAt:-1}).limit(200).lean()})));
app.patch('/api/admin/reviews/:id',auth,verified,admin,wrap(async(req,res)=>{const status=z.enum(['published','rejected']).parse(req.body.status);const review=await Review.findByIdAndUpdate(req.params.id,{$set:{status}},{new:true});if(!review)return res.status(404).json({error:'Not found'});res.json({review});}));
// Refill schedule records. NO scheduled notification worker is claimed or started.
app.post('/api/refills',auth,verified,wrap(async(req,res)=>{const v=z.object({medicine:z.string().trim().min(2).max(150),dueAt:z.coerce.date(),consent:z.literal(true)}).parse(req.body);if(v.dueAt<=new Date())return res.status(400).json({error:'Choose a future date'});const refill=await Refill.create({user:req.user._id,...v});res.status(201).json({refill});}));
app.get('/api/refills',auth,wrap(async(req,res)=>res.json({refills:await Refill.find({user:req.user._id}).sort({dueAt:1}).limit(100).lean()})));
app.patch('/api/refills/:id',auth,wrap(async(req,res)=>{const status=z.enum(['active','paused','cancelled']).parse(req.body.status);const refill=await Refill.findOneAndUpdate({_id:req.params.id,user:req.user._id},{$set:{status}},{new:true});if(!refill)return res.status(404).json({error:'Not found'});res.json({refill});}));
// Admin assignment + delivery staff progress. No GPS tracking without rider consent/mobile reporting.
app.post('/api/admin/deliveries',auth,verified,admin,wrap(async(req,res)=>{const v=z.object({orderId:z.string().regex(/^[a-f0-9]{24}$/i),riderId:z.string().regex(/^[a-f0-9]{24}$/i),eta:z.coerce.date().optional()}).parse(req.body);const rider=await User.findOne({_id:v.riderId,role:'delivery'});if(!rider)return res.status(404).json({error:'Delivery agent not found'});const order=await Order.findById(v.orderId);if(!order||!['shipped','paid','cod_pending'].includes(order.status))return res.status(409).json({error:'Order is not dispatchable'});const d=await Delivery.findOneAndUpdate({order:v.orderId},{$set:{rider:rider._id,eta:v.eta,status:'assigned'},$push:{events:{status:'assigned',at:new Date()}}},{upsert:true,new:true});await pushCustomerNotice(order.user,order._id,'Delivery assigned','A delivery rider has been assigned to your order.');res.json({delivery:d});}));
app.get('/api/deliveries',auth,wrap(async(req,res)=>{const orderIds=await Order.find({user:req.user._id}).distinct('_id');res.json({deliveries:await Delivery.find({order:{$in:orderIds}}).select('-locationNote').lean()});}));
app.get('/api/staff/deliveries',auth,verified,deliveryStaff,wrap(async(req,res)=>res.json({deliveries:await Delivery.find(req.user.role==='admin'?{}:{rider:req.user._id}).sort({updatedAt:-1}).limit(200).lean()})));
app.patch('/api/staff/deliveries/:id',auth,verified,deliveryStaff,wrap(async(req,res)=>{const status=z.enum(['picked_up','on_the_way','delivered']).parse(req.body.status);const filter={_id:req.params.id,...(req.user.role==='admin'?{}:{rider:req.user._id})};const current=await Delivery.findOne(filter);if(!current)return res.status(404).json({error:'Delivery not found'});const next={assigned:'picked_up',picked_up:'on_the_way',on_the_way:'delivered'}[current.status];if(status!==next)return res.status(409).json({error:'Invalid delivery transition'});const d=await Delivery.findOneAndUpdate({...filter,status:current.status},{$set:{status},$push:{events:{status,at:new Date()}}},{new:true});if(!d)return res.status(409).json({error:'Refresh and retry'});if(status==='delivered'){const o=await Order.findOneAndUpdate({_id:d.order,status:'shipped'},{$set:{status:'delivered'},$push:{statusHistory:{status:'delivered',at:new Date()}}},{new:true});if(o){const customer=await User.findById(o.user);if(customer){await pushCustomerNotice(customer._id,o._id,'Order delivered','Your MEDILINK order has been marked delivered.');await notifyOrder(customer,o,'order_update');}}}res.json({delivery:d});}));

// Administrative order queue and role-scoped delivery reporting.
app.get('/api/admin/orders',auth,verified,admin,wrap(async(req,res)=>res.json({orders:await Order.find().sort({createdAt:-1}).limit(150).populate('user','name email').lean()})));
app.get('/api/admin/riders',auth,verified,admin,wrap(async(req,res)=>res.json({riders:await User.find({role:'delivery',emailVerified:true}).select('name email').sort({name:1}).lean()})));
app.get('/api/notifications',auth,wrap(async(req,res)=>res.json({notifications:await InAppNotification.find({user:req.user._id}).sort({createdAt:-1}).limit(100).lean()})));
app.patch('/api/notifications/:id/read',auth,wrap(async(req,res)=>{const notice=await InAppNotification.findOneAndUpdate({_id:oid.parse(req.params.id),user:req.user._id},{$set:{readAt:new Date()}},{new:true});if(!notice)return res.status(404).json({error:'Notification not found'});res.json({notification:notice});}));
// Rider-to-customer GPS uses consentful location sharing; no Google Maps API key is required for the map link.
app.get('/api/admin/deliveries/map',auth,verified,admin,wrap(async(req,res)=>{const deliveries=await Delivery.find().sort({updatedAt:-1}).limit(150).lean();const ids=deliveries.map(d=>d._id);const positions=await RiderPosition.find({delivery:{$in:ids},sharing:true}).lean();const byId=new Map(positions.map(pos=>[String(pos.delivery),pos]));res.json({deliveries:deliveries.map(d=>({...d,position:byId.get(String(d._id))||null}))});}));
app.get('/api/admin/analytics',auth,verified,admin,wrap(async(req,res)=>{const [orders,customers,prescriptions,returns]=await Promise.all([Order.countDocuments(),User.countDocuments({role:'customer'}),Prescription.countDocuments(),ReturnRequest.countDocuments()]);const totals=await Order.aggregate([{$match:{status:{$in:['paid','shipped','delivered','cod_pending']}}},{$group:{_id:'$currency',amountMinor:{$sum:'$totalMinor'},orders:{$sum:1}}}]);res.json({orders,customers,prescriptions,returns,totals,note:'COD totals are orders placed, not confirmed cash receipts.'});}));

// --- Pending proposal: bounded operational workflows (not licensed clinical/financial certification) ---
const PharmacistCredential=mongoose.model('PharmacistCredential',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',required:true,unique:true},registrationNumber:{type:String,required:true},council:{type:String,required:true},status:{type:String,enum:['pending','verified','rejected'],default:'pending'},reviewedBy:{type:Schema.Types.ObjectId,ref:'User'},reviewedAt:Date,notes:{type:String,maxlength:500}},opts));
const ChatThread=mongoose.model('ChatThread',new Schema({customer:{type:Schema.Types.ObjectId,ref:'User',required:true,index:true},pharmacist:{type:Schema.Types.ObjectId,ref:'User'},status:{type:String,enum:['open','closed'],default:'open'},topic:{type:String,required:true,maxlength:160}},opts));
const ChatMessage=mongoose.model('ChatMessage',new Schema({thread:{type:Schema.Types.ObjectId,ref:'ChatThread',required:true,index:true},sender:{type:Schema.Types.ObjectId,ref:'User',required:true},text:{type:String,required:true,maxlength:1500}},opts));
const RiderPosition=mongoose.model('RiderPosition',new Schema({delivery:{type:Schema.Types.ObjectId,ref:'Delivery',required:true,unique:true},rider:{type:Schema.Types.ObjectId,ref:'User',required:true},latitude:{type:Number,required:true},longitude:{type:Number,required:true},updatedAt:{type:Date,default:Date.now},sharing:{type:Boolean,default:true}},opts));
const RefillDispatch=mongoose.model('RefillDispatch',new Schema({refill:{type:Schema.Types.ObjectId,ref:'Refill',required:true},dateKey:{type:String,required:true},status:{type:String,default:'reserved'},attemptedAt:Date},opts));
RefillDispatch.schema.index({refill:1,dateKey:1},{unique:true});
const oid=z.string().regex(/^[0-9a-f]{24}$/i);
const verifiedPharmacist=async(req,res,next)=>{if(req.user.role==='admin')return next();if(req.user.role!=='pharmacist')return res.status(403).json({error:'Pharmacist role required'});const cred=await PharmacistCredential.findOne({user:req.user._id,status:'verified'});if(!cred)return res.status(403).json({error:'Registration verification is pending'});next();};
app.post('/api/pharmacists/credentials',auth,verified,wrap(async(req,res)=>{if(req.user.role!=='pharmacist')return res.status(403).json({error:'Pharmacist role required'});const v=z.object({registrationNumber:z.string().trim().min(4).max(70),council:z.string().trim().min(3).max(120)}).parse(req.body);const credential=await PharmacistCredential.findOneAndUpdate({user:req.user._id},{$set:{...v,status:'pending'},$unset:{reviewedBy:1,reviewedAt:1,notes:1}},{upsert:true,new:true});res.json({credential});}));
app.get('/api/pharmacists/credentials/me',auth,wrap(async(req,res)=>res.json({credential:await PharmacistCredential.findOne({user:req.user._id}).lean()})));
app.get('/api/admin/pharmacists/credentials',auth,verified,admin,wrap(async(req,res)=>res.json({credentials:await PharmacistCredential.find().populate('user','name email').limit(150).lean()})));
app.patch('/api/admin/pharmacists/credentials/:id',auth,verified,admin,wrap(async(req,res)=>{const v=z.object({status:z.enum(['verified','rejected']),notes:z.string().max(500).optional()}).parse(req.body);const credential=await PharmacistCredential.findByIdAndUpdate(oid.parse(req.params.id),{$set:{...v,reviewedBy:req.user._id,reviewedAt:new Date()}},{new:true});if(!credential)return res.status(404).json({error:'Not found'});await AuditLog.create({actor:req.user._id,action:'credential_'+v.status,target:String(credential._id)});res.json({credential,warning:'Admin must independently check registration against the issuing regulator; this UI does not perform regulator verification.'});}));
app.post('/api/chat/threads',auth,verified,wrap(async(req,res)=>{const {topic}=z.object({topic:z.string().trim().min(5).max(160)}).parse(req.body);const thread=await ChatThread.create({customer:req.user._id,topic});res.status(201).json({thread});}));
app.get('/api/chat/threads',auth,wrap(async(req,res)=>{const eligible=await PharmacistCredential.exists({user:req.user._id,status:'verified'});const filter=req.user.role==='admin'||(req.user.role==='pharmacist'&&eligible)?{}:{customer:req.user._id};res.json({threads:await ChatThread.find(filter).sort({updatedAt:-1}).limit(100).lean()});}));
async function canChat(req,thread){if(!thread)return false;if(String(thread.customer)===String(req.user._id)||req.user.role==='admin')return true;return req.user.role==='pharmacist'&&Boolean(await PharmacistCredential.exists({user:req.user._id,status:'verified'}));}
app.get('/api/chat/threads/:id/messages',auth,wrap(async(req,res)=>{const thread=await ChatThread.findById(oid.parse(req.params.id));if(!await canChat(req,thread))return res.status(403).json({error:'Not authorized'});res.json({messages:await ChatMessage.find({thread:thread._id}).sort({createdAt:1}).limit(250).lean()});}));
app.post('/api/chat/threads/:id/messages',auth,verified,wrap(async(req,res)=>{const thread=await ChatThread.findById(oid.parse(req.params.id));if(!await canChat(req,thread))return res.status(403).json({error:'Not authorized'});if(thread.status!=='open')return res.status(409).json({error:'Conversation is closed'});const {text}=z.object({text:z.string().trim().min(1).max(1500)}).parse(req.body);const message=await ChatMessage.create({thread:thread._id,sender:req.user._id,text});await ChatThread.updateOne({_id:thread._id},{$set:{updatedAt:new Date()}});res.status(201).json({message});}));
app.patch('/api/chat/threads/:id',auth,wrap(async(req,res)=>{const thread=await ChatThread.findById(oid.parse(req.params.id));if(!await canChat(req,thread))return res.status(403).json({error:'Not authorized'});thread.status=z.enum(['open','closed']).parse(req.body.status);await thread.save();res.json({thread});}));
app.put('/api/staff/deliveries/:id/location',auth,verified,deliveryStaff,wrap(async(req,res)=>{const v=z.object({latitude:z.number().min(-90).max(90),longitude:z.number().min(-180).max(180),consent:z.literal(true)}).parse(req.body);const d=await Delivery.findOne({_id:oid.parse(req.params.id),rider:req.user._id});if(!d)return res.status(404).json({error:'Only the assigned rider can share GPS location'});if(['delivered','cancelled'].includes(d.status))return res.status(409).json({error:'Delivery finished'});const position=await RiderPosition.findOneAndUpdate({delivery:d._id},{$set:{rider:req.user._id,latitude:v.latitude,longitude:v.longitude,updatedAt:new Date(),sharing:true}},{upsert:true,new:true});res.json({position});}));
app.delete('/api/staff/deliveries/:id/location',auth,deliveryStaff,wrap(async(req,res)=>{const d=await Delivery.findOne({_id:oid.parse(req.params.id),...(req.user.role==='admin'?{}:{rider:req.user._id})});if(!d)return res.status(404).json({error:'Delivery not found'});await RiderPosition.deleteOne({delivery:d._id});res.json({ok:true});}));
app.get('/api/deliveries/:id/location',auth,wrap(async(req,res)=>{const d=await Delivery.findById(oid.parse(req.params.id));if(!d)return res.status(404).json({error:'Not found'});const owner=await Order.exists({_id:d.order,user:req.user._id});if(!owner&&String(d.rider)!==String(req.user._id)&&req.user.role!=='admin')return res.status(403).json({error:'Not authorized'});const p=await RiderPosition.findOne({delivery:d._id,sharing:true}).lean();if(!p||Date.now()-new Date(p.updatedAt).getTime()>5*60_000)return res.json({position:null,stale:true});res.json({position:{latitude:p.latitude,longitude:p.longitude,updatedAt:p.updatedAt},stale:false});}));
// Safety: this is a curated catalogue information route, NOT symptom diagnosis or autonomous substitutions.

// MEDILINK Health Helper: non-diagnostic, privacy-minimising product discovery.
const HealthHelperLog=mongoose.model('HealthHelperLog',new Schema({user:{type:Schema.Types.ObjectId,ref:'User',index:true},topic:String,mode:String,createdAt:{type:Date,default:Date.now}},opts));
const helpLimiter=rateLimit({windowMs:15*60*1000,limit:15,standardHeaders:'draft-7',legacyHeaders:false});
const urgentPattern=/\b(chest pain|cannot breathe|can't breathe|difficulty breathing|severe shortness of breath|stroke|one.side weakness|unconscious|suicid|overdose|anaphylaxis|swollen tongue|severe allergic reaction|seizure|severe bleeding)\b|පපුවේ වේදනාව|හුස්ම ගන්න බැ|හුස්ම ගැනීමේ අපහසු|අධික රුධිර වහනය|සිහි නැති/iu;
const vulnerablePattern=/\b(pregnant|pregnancy|infant|newborn|baby|under 5|chemotherapy|immunocompromised)\b|ගර්භණී|ළදරු/iu;
const safeHealthText = `I can share general health information and suggest non-medicinal wellness products, but cannot diagnose a condition, select medicines from symptoms, change doses, or substitute prescribed medicines. If symptoms worsen, persist, or you are concerned, consult a registered clinician or pharmacist.`;
app.post('/api/health-helper/ask',helpLimiter,auth,wrap(async(req,res)=>{
 const body=z.object({message:z.string().trim().min(3).max(900),useOrderHistory:z.boolean().default(false)}).parse(req.body);
 const message=body.message;
 const urgent=urgentPattern.test(message);
 const vulnerable=vulnerablePattern.test(message);
 let response=urgent?'Your message may describe an urgent warning sign. Seek emergency medical care immediately or contact your local emergency number. Do not delay for this chat.':vulnerable?'For pregnancy, babies, and medically vulnerable people, please consult a qualified clinician or pharmacist before choosing OTC products.':safeHealthText;
 let mode='safety_guidance';
 // Do not transmit order history, identifiers, or contact details to an AI provider.
 // OpenRouter uses the OpenAI-compatible chat completions API; secrets are server-side only.
 const providerKey=(env.OPENROUTER_API_KEY||'').trim();
 const openAIKey=(env.OPENAI_API_KEY||'').trim();
 if(!urgent&&!vulnerable&&(providerKey||openAIKey)){
  try{
   const instructions='You are MEDILINK, an informational health helper in an online pharmacy. Respond in the same language as the user (Sinhala or English). Give cautious general health education, basic self-care and appropriate warning signs. Never diagnose, prescribe, suggest drug doses, recommend a medicine or OTC therapeutic alternative for symptoms, or substitute prescription medication. Do not claim you are a clinician. For medication choices, refer to a licensed pharmacist or doctor. Keep it under 140 words.';
   let r, content='';
   if(providerKey){
    r=await fetch('https://openrouter.ai/api/v1/chat/completions',{
     method:'POST',signal:AbortSignal.timeout(15000),
     headers:{Authorization:`Bearer ${providerKey}`,'Content-Type':'application/json','X-Title':'MEDILINK Health Helper'},
     body:JSON.stringify({model:env.OPENROUTER_MODEL||'openai/gpt-4o-mini',messages:[{role:'system',content:instructions},{role:'user',content:message}],max_tokens:320,temperature:0.3})
    });
    if(r.ok){const data=await r.json();content=typeof data?.choices?.[0]?.message?.content==='string'?data.choices[0].message.content.trim():'';}
   }else{
    r=await fetch('https://api.openai.com/v1/responses',{
     method:'POST',signal:AbortSignal.timeout(15000),
     headers:{Authorization:`Bearer ${openAIKey}`,'Content-Type':'application/json'},
     body:JSON.stringify({model:env.HEALTH_HELPER_MODEL||'gpt-4.1-mini',store:false,max_output_tokens:320,instructions,input:message})
    });
    if(r.ok){const data=await r.json();content=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join(' ').trim();}
   }
   if(content){response=content.slice(0,1800);mode='ai_guidance';}
   else console.warn('Health helper provider returned no usable response',r.status);
  }catch(e){console.warn('Health helper provider unavailable',String(e.message).slice(0,100));}
 }
 // Only non-prescription wellness accessories; these are NOT treatment alternatives.
 const safeCategories=/wellness|personal care|health essentials/i;
 let candidates=await Product.find({active:true,stock:{$gt:0},prescriptionRequired:false}).select('sku name priceMinor currency stock').limit(120).lean();
 candidates=candidates.filter(p=>/thermometer|mask|sanitiz|bandage|first aid|soap|sunscreen|moisturiz|oral hygiene|toothbrush|handwash|tissue/i.test(p.name));
 let preferred=new Set();
 if(body.useOrderHistory){const prior=await Order.find({user:req.user._id,status:{$in:['paid','cod_pending','shipped','delivered']}}).select('items.sku').sort({createdAt:-1}).limit(12).lean();preferred=new Set(prior.flatMap(o=>o.items||[]).map(i=>i.sku));}
 candidates.sort((a,b)=>Number(preferred.has(b.sku))-Number(preferred.has(a.sku)));
 const suggestions=candidates.slice(0,5).map(p=>({sku:p.sku,name:p.name,priceMinor:p.priceMinor,currency:p.currency,reason:preferred.has(p.sku)?'Previously purchased wellness/accessory item':'General wellness/accessory browsing only'}));
 await HealthHelperLog.create({user:req.user._id,topic:'general_health',mode}); // Do not store symptom text.
 res.json({reply:response,urgent,mode,suggestions,notice:'Product suggestions are not treatments for your symptoms. Ask a licensed pharmacist before buying or switching medications.'});
}));
app.get('/api/catalog/suggestions',wrap(async(req,res)=>{const sku=z.string().trim().min(1).max(120).parse(req.query.sku);const source=await Product.findOne({sku}).lean();if(!source)return res.status(404).json({error:'Product not found'});const products=await Product.find({sku:{$ne:sku},category:source.category,requiresRx:false,stock:{$gt:0}}).select('sku name category priceMinor currency').limit(6).lean();res.json({products,disclaimer:'General category browsing only. Not medical advice, a therapeutic alternative, or dosage recommendation. Ask a licensed pharmacist.'});}));
app.get('/api/payments/readiness',auth,wrap(async(req,res)=>res.json({payhere:{configured:payhereReady,certified:false},paypal:{configured:Boolean(env.PAYPAL_CLIENT_ID&&env.PAYPAL_CLIENT_SECRET),currencySupported:currency!=='LKR'},refunds:{automatic:false,manualReview:true},message:'Payment certification and refunds require verified merchant credentials, provider approval and audited live testing.'})));
// Refill delivery: a separate worker can call this with server-side REFILL_WORKER_KEY. Do not expose the key in frontend.
app.post('/api/internal/refills/dispatch',wrap(async(req,res)=>{const header=req.get('x-refill-worker-key')||'';if(!env.REFILL_WORKER_KEY||header.length!==env.REFILL_WORKER_KEY.length||!crypto.timingSafeEqual(Buffer.from(header),Buffer.from(env.REFILL_WORKER_KEY)))return res.status(403).json({error:'Not configured or unauthorized'});const now=new Date(),dateKey=now.toISOString().slice(0,10);const refills=await Refill.find({status:'active',consent:true,dueAt:{$lte:now,$gte:new Date(Date.now()-7*86400000)}}).limit(100);let processed=0;for(const r of refills){const reserved=await RefillDispatch.updateOne({refill:r._id,dateKey},{$setOnInsert:{refill:r._id,dateKey,status:'reserved'}},{upsert:true});if(!reserved.upsertedCount)continue;const u=await User.findById(r.user);if(!u||!u.emailVerified){await RefillDispatch.updateOne({refill:r._id,dateKey},{$set:{status:'skipped'}});continue;}await mail(u,'refill_reminder','MEDILINK prescription refill reminder',`Your planned refill date for ${r.medicine} is due. Contact your pharmacist to confirm prescription validity and suitability. No medicine has been ordered automatically.`);await sms(u,'refill_reminder',`MEDILINK: Planned refill reminder for ${r.medicine}. Please confirm with your pharmacist.`);await RefillDispatch.updateOne({refill:r._id,dateKey},{$set:{status:'attempted',attemptedAt:new Date()}});processed++;}res.json({processed,checked:refills.length,note:'Run from a trusted scheduled job; delivery and approval are not guaranteed.'});}));

app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(err.code==='LIMIT_FILE_SIZE'?413:400).json({error:err.code==='LIMIT_FILE_SIZE'?'File exceeds 80 MB':'Invalid upload'});if(err instanceof z.ZodError)return res.status(400).json({error:'Invalid request',issues:err.issues.map(i=>({path:i.path,message:i.message}))});if(err?.code===11000)return res.status(409).json({error:'Duplicate record'});console.error(err);res.status(err.status||500).json({error:err.status?err.message:'Internal server error'});});
await mongoose.connect(env.MONGODB_URI,{serverSelectionTimeoutMS:10000});
if(env.SEED_DEMO_PRODUCTS==='true'){const rows=JSON.parse(fs.readFileSync(new URL('./catalog.json',import.meta.url),'utf8'));for(const row of rows)await Product.updateOne({sku:row.sku},{$setOnInsert:row},{upsert:true});console.log(`Seeded ${rows.length} products (insert-only)`);}
if(env.ADMIN_EMAIL){
 const target=env.ADMIN_EMAIL.trim().toLowerCase();
 const adminAccount=await User.findOne({email:target}).select('email emailVerified role googleSub passwordHash').select('+passwordHash');
 if(!adminAccount)console.warn('[ADMIN SETUP] Configured admin email has no registered account. Register using /account first.');
 else if(!adminAccount.emailVerified)console.warn('[ADMIN SETUP] Admin email account is not verified. Complete email verification, then retry.');
 else {
   if(adminAccount.role==='customer'){
     await User.updateOne({_id:adminAccount._id,role:'customer',emailVerified:true},{$set:{role:'admin'}});
     console.log('[ADMIN SETUP] Verified configured email promoted to admin.');
   }
   if(!adminAccount.passwordHash)console.warn('[ADMIN SETUP] Admin user has no password credential (possibly Google sign-in). Password login is unavailable.');
 }
}
app.listen(Number(env.PORT||4000),()=>console.log(`MEDILINK API on http://localhost:${env.PORT||4000}`));
