import 'dotenv/config';
import mongoose from 'mongoose';
const {MONGODB_URI,ADMIN_EMAIL}=process.env;
if(!MONGODB_URI||!ADMIN_EMAIL){console.error('Set MONGODB_URI and ADMIN_EMAIL in backend/.env');process.exit(1);}
try{
 await mongoose.connect(MONGODB_URI,{serverSelectionTimeoutMS:10000});
 const users=mongoose.connection.db.collection('users');
 const email=ADMIN_EMAIL.trim().toLowerCase();
 const user=await users.findOne({email},{projection:{email:1,emailVerified:1,role:1,passwordHash:1,googleSub:1}});
 if(!user)console.log('STATUS: ACCOUNT_NOT_FOUND — Register first at /account.');
 else{
  console.log('STATUS:',user.emailVerified?'EMAIL_VERIFIED':'EMAIL_NOT_VERIFIED');
  console.log('ROLE:',user.role||'customer');
  console.log('PASSWORD_LOGIN:',user.passwordHash?'AVAILABLE':'NOT_CONFIGURED');
  console.log('GOOGLE_SIGN_IN:',user.googleSub?'LINKED':'NOT_LINKED');
  if(!user.passwordHash)console.log('NEXT: Use existing password registration/account recovery; Google-only account cannot use the admin password form.');
  if(!user.emailVerified)console.log('NEXT: Verify email via issued MEDILINK verification link.');
  else if(user.role!=='admin')console.log('NEXT: Restart backend with ADMIN_EMAIL configured to apply verified bootstrap.');
  else console.log('NEXT: Sign in at /admin/login using the existing account password.');
 }
} catch(e){console.error('Diagnostic failed:',e.message);process.exitCode=1;}
finally{await mongoose.disconnect();}
